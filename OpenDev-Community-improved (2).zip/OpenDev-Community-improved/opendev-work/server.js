require("dotenv").config();
const express = require("express");
const session = require("express-session");
const cookieParser = require("cookie-parser");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;
const admins = new Set((process.env.ADMIN_DISCORD_IDS || "1552721267415584799,1355150439057985687").split(",").map(s => s.trim()).filter(Boolean));

app.use(express.json({limit:"2mb"}));
app.use(cookieParser());
const sessionMiddleware = session({
  secret: process.env.SESSION_SECRET || "dev-only-change-this-secret",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly:true, sameSite:"lax", secure:process.env.NODE_ENV === "production", maxAge: 7*24*60*60*1000 }
});
app.use(sessionMiddleware);
io.engine.use(sessionMiddleware);
app.use(express.static("public"));

const roomMembers = new Map();
const generalChat = [];
const builtinRooms = new Set(["lobby", "pair"]);
const store = {
  users: new Map(), projects: [], likes: new Set(), notifications: [], messages: [], forum: [], challenges: [],
  rooms: new Map()
};
const id = () => crypto.randomUUID();
const me = (req) => req.session.user || null;
function requireAuth(req,res,next){ if(!me(req)) return res.status(401).json({error:"Entre com o Discord para continuar."}); next(); }
function requireAdmin(req,res,next){ if(!me(req) || !admins.has(me(req).id)) return res.status(403).json({error:"Acesso restrito."}); next(); }

app.get("/api/config", (req,res)=>res.json({discordConfigured:!!(process.env.DISCORD_CLIENT_ID && process.env.DISCORD_CLIENT_SECRET), user:me(req), isAdmin:!!me(req)&&admins.has(me(req).id), ownerIds:[...admins]}));
app.get("/auth/discord", (req,res)=>{
  if(!process.env.DISCORD_CLIENT_ID || !process.env.DISCORD_CLIENT_SECRET) return res.status(503).send("Configure DISCORD_CLIENT_ID e DISCORD_CLIENT_SECRET no .env para ativar o login.");
  const state=crypto.randomBytes(24).toString("hex"); req.session.oauthState=state;
  const params=new URLSearchParams({client_id:process.env.DISCORD_CLIENT_ID,redirect_uri:process.env.DISCORD_CALLBACK_URL||`${process.env.PUBLIC_BASE_URL||`http://localhost:${PORT}`}/auth/discord/callback`,response_type:"code",scope:"identify",state});
  res.redirect("https://discord.com/oauth2/authorize?"+params.toString());
});
app.get("/auth/discord/callback", async (req,res)=>{
  try {
    if(!req.query.code || req.query.state!==req.session.oauthState) return res.status(400).send("Autorização inválida. Volte e tente novamente.");
    const redirectUri=process.env.DISCORD_CALLBACK_URL||`${process.env.PUBLIC_BASE_URL||`http://localhost:${PORT}`}/auth/discord/callback`;
    const tokenResp=await fetch("https://discord.com/api/oauth2/token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({client_id:process.env.DISCORD_CLIENT_ID,client_secret:process.env.DISCORD_CLIENT_SECRET,grant_type:"authorization_code",code:req.query.code,redirect_uri:redirectUri})});
    const token=await tokenResp.json(); if(!token.access_token) return res.status(400).send("Não foi possível validar o login Discord.");
    const userResp=await fetch("https://discord.com/api/users/@me",{headers:{Authorization:`Bearer ${token.access_token}`}});
    const d=await userResp.json(); if(!d.id) return res.status(400).send("Não foi possível obter seu perfil Discord.");
    const user={id:d.id,username:d.global_name||d.username,tag:d.username,avatar:d.avatar?`https://cdn.discordapp.com/avatars/${d.id}/${d.avatar}.${d.avatar.startsWith("a_")?"gif":"png"}?size=256`:null,bio:"",createdAt:new Date().toISOString()};
    const saved=store.users.get(user.id)||{};const merged={...saved,...user,bio:saved.bio||user.bio||"",avatar:saved.avatar||user.avatar,username:saved.username||user.username};store.users.set(user.id,merged); req.session.user=merged; res.redirect("/");
  } catch(e){console.error(e);res.status(500).send("Erro no login. Tente novamente.");}
});
app.post("/auth/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me", (req,res)=>res.json({user:me(req),isAdmin:!!me(req)&&admins.has(me(req).id)}));
app.patch("/api/profile",requireAuth,(req,res)=>{
  const u=store.users.get(me(req).id)||me(req); const {username,bio,avatar}=req.body;
  if(username!==undefined) u.username=String(username).trim().slice(0,32);
  if(bio!==undefined) u.bio=String(bio).trim().slice(0,180);
  if(avatar!==undefined) u.avatar=String(avatar).trim().slice(0,500);
  store.users.set(u.id,u); req.session.user=u; res.json({user:u});
});
app.get("/api/projects",(req,res)=>res.json(store.projects.slice().sort((a,b)=>b.likes-a.likes)));
app.post("/api/projects",requireAuth,(req,res)=>{
  const title=String(req.body.title||"").trim().slice(0,80), description=String(req.body.description||"").trim().slice(0,600), url=String(req.body.url||"").trim().slice(0,500), language=String(req.body.language||"Outro").slice(0,30);
  if(!title||!description) return res.status(400).json({error:"Preencha o nome e a descrição."});
  const p={id:id(),title,description,url,language,ownerId:me(req).id,ownerName:me(req).username,createdAt:new Date().toISOString(),likes:0};
  store.projects.push(p); io.emit("project:new",p); res.status(201).json(p);
});
app.delete("/api/projects/:id",requireAuth,(req,res)=>{const i=store.projects.findIndex(p=>p.id===req.params.id);if(i<0)return res.status(404).json({error:"Projeto não encontrado."});const p=store.projects[i];if(p.ownerId!==me(req).id&&!admins.has(me(req).id))return res.status(403).json({error:"Você só pode apagar seus próprios projetos."});store.projects.splice(i,1);for(const key of [...store.likes])if(key.endsWith(":"+p.id))store.likes.delete(key);io.emit("project:deleted",{id:p.id});res.json({ok:true})});
app.post("/api/projects/:id/like",requireAuth,(req,res)=>{
  const p=store.projects.find(p=>p.id===req.params.id); if(!p)return res.status(404).json({error:"Projeto não encontrado."});
  const key=`${me(req).id}:${p.id}`; if(store.likes.has(key)){store.likes.delete(key);p.likes=Math.max(0,p.likes-1)}else{store.likes.add(key);p.likes++}
  io.emit("project:updated",p);res.json({likes:p.likes,liked:store.likes.has(key)});
});
app.get("/api/rank",(req,res)=>res.json([...store.users.values()].map(u=>({id:u.id,username:u.username,avatar:u.avatar,bio:u.bio,projects:store.projects.filter(p=>p.ownerId===u.id).length,likes:store.projects.filter(p=>p.ownerId===u.id).reduce((n,p)=>n+p.likes,0)})).sort((a,b)=>b.likes-a.likes)));
app.get("/api/forum",(req,res)=>res.json(store.forum.slice().reverse()));
app.post("/api/forum",requireAuth,(req,res)=>{const title=String(req.body.title||"").trim().slice(0,100),body=String(req.body.body||"").trim().slice(0,2000);if(!title||!body)return res.status(400).json({error:"Preencha título e conteúdo."});const post={id:id(),title,body,ownerId:me(req).id,ownerName:me(req).username,createdAt:new Date().toISOString(),comments:[]};store.forum.push(post);io.emit("forum:new",post);res.status(201).json(post)});
app.delete("/api/admin/notifications/:id",requireAdmin,(req,res)=>{const i=store.notifications.findIndex(n=>n.id===req.params.id);if(i<0)return res.status(404).json({error:"Notificação não encontrada."});store.notifications.splice(i,1);io.emit("notification:deleted",{id:req.params.id});res.json({ok:true})});
app.get("/api/users",requireAuth,(req,res)=>res.json([...store.users.values()].filter(u=>u.id!==me(req).id).map(u=>({id:u.id,username:u.username,avatar:u.avatar,bio:u.bio,projects:store.projects.filter(p=>p.ownerId===u.id).length})).sort((a,b)=>a.username.localeCompare(b.username))));
app.get("/api/dm/conversations",requireAuth,(req,res)=>{const uid=me(req).id;const ids=new Set();for(const m of store.messages){if(m.from===uid)ids.add(m.to);if(m.to===uid)ids.add(m.from)}res.json([...ids].map(otherId=>{const u=store.users.get(otherId)||{id:otherId,username:"Desenvolvedor",avatar:null};const last=store.messages.filter(m=>(m.from===uid&&m.to===otherId)||(m.from===otherId&&m.to===uid)).sort((a,b)=>b.createdAt.localeCompare(a.createdAt))[0];return {user:{id:u.id,username:u.username,avatar:u.avatar,bio:u.bio},lastMessage:last}}).sort((a,b)=>(b.lastMessage?.createdAt||"").localeCompare(a.lastMessage?.createdAt||"")))});
app.get("/api/notifications",(req,res)=>res.json(me(req)?store.notifications.filter(n=>n.target==="all"||n.target===me(req).id):[]));
app.post("/api/admin/notifications",requireAdmin,(req,res)=>{const title=String(req.body.title||"").trim().slice(0,100),body=String(req.body.body||"").trim().slice(0,500);if(!title||!body)return res.status(400).json({error:"Informe título e mensagem."});const n={id:id(),title,body,target:"all",createdAt:new Date().toISOString(),author:me(req).username};store.notifications.push(n);io.emit("notification:new",n);res.status(201).json(n)});
app.get("/api/admin/users",requireAdmin,(req,res)=>res.json([...store.users.values()].map(u=>({id:u.id,username:u.username,avatar:u.avatar,bio:u.bio}))));
app.post("/api/admin/users",requireAdmin,(req,res)=>{const uid=String(req.body.discordId||"").trim();if(!/^\d{17,20}$/.test(uid))return res.status(400).json({error:"Informe um ID de usuário Discord válido."});const u=store.users.get(uid);if(!u)return res.status(404).json({error:"A pessoa precisa entrar no site pelo Discord pelo menos uma vez."});res.json({ok:true,user:u})});
app.get("/api/dm/:userId",requireAuth,(req,res)=>res.json(store.messages.filter(m=>(m.from===me(req).id&&m.to===req.params.userId)||(m.to===me(req).id&&m.from===req.params.userId))));
app.post("/api/dm/:userId",requireAuth,(req,res)=>{const body=String(req.body.body||"").trim().slice(0,2000);if(!body)return res.status(400).json({error:"Mensagem vazia."});const m={id:id(),from:me(req).id,to:req.params.userId,body,createdAt:new Date().toISOString()};store.messages.push(m);io.emit("dm:new",m);res.status(201).json(m)});
app.get("/api/challenges",(req,res)=>res.json(store.challenges));
app.post("/api/challenges/:id/submit",requireAuth,(req,res)=>res.json({ok:true,message:"Envio recebido nesta demonstração. Configure persistência para guardar submissões."}));

io.use((socket,next)=>{socket.data.user=socket.request.session?.user||null;next()});
io.on("connection",socket=>{
  socket.data.rooms = new Set();
  socket.on("chat:history",ack=>{if(typeof ack==="function")ack(generalChat.slice(-100));else socket.emit("chat:history",generalChat.slice(-100))});
  socket.on("chat:send",payload=>{const u=socket.data.user;if(!u)return;const body=String(payload?.body||"").trim().slice(0,1000);if(!body)return;const m={id:id(),userId:u.id,username:u.username,body,createdAt:new Date().toISOString()};generalChat.push(m);if(generalChat.length>200)generalChat.shift();io.emit("chat:new",m)});
  socket.on("room:list",ack=>{const rooms=[...store.rooms.values()].map(r=>({...r,members:[...(roomMembers.get(r.id)?.values()||[])]}));if(typeof ack==="function")ack(rooms);for(const [roomId,members] of roomMembers.entries())socket.emit("room:members",{roomId,members:[...members.values()]}) });
  socket.on("room:create",(payload,ack)=>{if(!socket.data.user)return typeof ack==="function"&&ack({ok:false,error:"Entre com o Discord para criar uma call."});const name=String(payload?.name||"").trim().slice(0,48);if(!name)return typeof ack==="function"&&ack({ok:false,error:"Informe um nome para a sala."});const roomId="custom-"+crypto.randomUUID();const room={id:roomId,name,createdBy:socket.data.user.id,createdAt:new Date().toISOString()};store.rooms.set(roomId,room);if(typeof ack==="function")ack({ok:true,room});io.emit("room:created",room)});
  socket.on("room:join",({roomId,username,userId,avatar}={})=>{if(!roomId||typeof roomId!=="string")return;if(!socket.data.user)return;const u=socket.data.user;username=u.username;userId=u.id;avatar=u.avatar;if(roomId.startsWith("dm-")){const allowed=roomId.slice(3).split("-");if(!allowed.includes(u.id))return}else if(!builtinRooms.has(roomId)&&!store.rooms.has(roomId))return;socket.join(roomId);socket.data.rooms.add(roomId);if(!roomMembers.has(roomId))roomMembers.set(roomId,new Map());const existingPeers=[...roomMembers.get(roomId).keys()];socket.emit("room:existing-peers",{roomId,peers:existingPeers});roomMembers.get(roomId).set(socket.id,{socketId:socket.id,userId:userId||null,username:String(username||"Desenvolvedor").slice(0,32),avatar:avatar||null});io.to(roomId).emit("room:members",{roomId,members:[...roomMembers.get(roomId).values()]});socket.to(roomId).emit("room:peer-joined",{socketId:socket.id,roomId,username:username||"Desenvolvedor"});});
  socket.on("room:leave",({roomId}={})=>{if(!roomId)return;socket.to(roomId).emit("room:peer-left",{socketId:socket.id});socket.leave(roomId);socket.data.rooms.delete(roomId);const members=roomMembers.get(roomId);if(members){members.delete(socket.id);io.to(roomId).emit("room:members",{roomId,members:[...members.values()]});if(!members.size){roomMembers.delete(roomId);if(store.rooms.has(roomId)){store.rooms.delete(roomId);io.emit("room:deleted",{roomId})}}}});
  socket.on("rtc:signal",({to,signal,roomId})=>{if(to&&signal&&socket.data.rooms?.has(roomId)&&io.sockets.sockets.get(to)?.data.rooms?.has(roomId))io.to(to).emit("rtc:signal",{from:socket.id,signal,roomId})});
  socket.on("room:state",({roomId,state})=>socket.to(roomId).emit("room:state",{from:socket.id,state}));
  socket.on("disconnect",()=>{for(const roomId of socket.data.rooms||[]){const members=roomMembers.get(roomId);if(members){members.delete(socket.id);io.to(roomId).emit("room:members",{roomId,members:[...members.values()]});io.to(roomId).emit("room:peer-left",{socketId:socket.id});if(!members.size){roomMembers.delete(roomId);if(store.rooms.has(roomId)){store.rooms.delete(roomId);io.emit("room:deleted",{roomId})}}}}});
});
server.listen(PORT,()=>console.log(`OpenDev rodando em http://localhost:${PORT}`));
