# OpenDev Community

Comunidade de programação com visual escuro inspirado em dashboards de repositórios. O estado inicial é vazio: sem projetos, curtidas, perfis, mensagens ou ranking falsos.

## Requisitos
- Node.js 18+ (recomendado Node 20+)
- Aplicação Discord criada no Developer Portal para OAuth
- HTTPS em produção para microfone e compartilhamento de tela

## Rodar localmente
1. Extraia o ZIP e abra esta pasta no VS Code.
2. No terminal, execute `npm install`.
3. Copie `.env.example` para `.env`.
4. Preencha `SESSION_SECRET`, `DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET` e `DISCORD_CALLBACK_URL`.
5. No Discord Developer Portal > OAuth2, cadastre o redirect URI exatamente igual a `DISCORD_CALLBACK_URL`.
6. Execute `npm start` e abra `http://localhost:3000`.

## OAuth Discord
O login é implementado com OAuth2 `identify`. Nunca coloque o client secret no frontend. Em hospedagem, configure variáveis de ambiente e um callback HTTPS.

## Administradores
Os IDs autorizados solicitados estão no `.env.example`:
- `1552721267415584799`
- `1355150439057985687`

A autorização é verificada no backend. Configure `ADMIN_DISCORD_IDS` nas variáveis de ambiente do servidor.

## O que está implementado
- Dashboard responsivo escuro e verde-lima, baseado na referência.
- Exploração sem login; ações de criação/curtida protegidas por login.
- OAuth Discord real quando as credenciais estiverem configuradas.
- Publicação de projetos, ordenação por curtidas e DevRank calculado a partir de dados existentes.
- Tópicos do DevForum.
- Perfil editável (nome público, bio e URL de avatar).
- Painel admin restrito por ID e envio de notificações com indicador.
- Aviso de entrada para `https://discord.gg/programador`.
- Área de mensagens diretas com lista de conversas, descoberta de perfis, envio de mensagens e botão para chamada privada com a pessoa da DM.
- Chat geral em tempo real via Socket.IO, com histórico limitado à memória do processo.
- Salas de voz padrão e criação de salas temporárias, removidas quando o último participante sai.
- Controles de microfone e compartilhamento de tela quando o navegador oferece a API necessária. A prévia da tela é privada para quem está transmitindo; dispositivos móveis podem não oferecer captura de tela no navegador.
- Emblemas transparentes de administrador e membro ao lado dos nomes, fundo preto, cartões com animação suave e navegação responsiva para celular.
- Socket.IO com sessão compartilhada para identificar usuários conectados.

## Importante: persistência e chamadas em grupo
Esta versão é um starter executável, não um serviço pronto para produção. Os dados de projetos, curtidas, usuários, notificações, fórum e DMs ficam em memória e serão perdidos ao reiniciar. Antes de abrir ao público, use PostgreSQL (ou equivalente), migrações, rate limiting, validação de URLs, moderação e armazenamento de imagens.

Os controles de microfone e tela demonstram permissões/controles locais. Para chamadas reais entre múltiplos usuários com áudio e compartilhamento de tela, integre um SFU WebRTC como LiveKit ou mediasoup, com tokens gerados no backend e salas autenticadas. Socket.IO sozinho não transporta mídia. A base inclui eventos de sinalização, mas não afirma que uma chamada em grupo esteja completa.

O chat geral, as DMs, as salas temporárias e os projetos continuam em memória nesta versão; reiniciar o servidor limpa esses dados. As salas exibem presença em tempo real, mas áudio em grupo real ainda precisa de um servidor SFU/WebRTC. A função de adicionar usuário no painel verifica contas que já fizeram login; não cria contas Discord arbitrárias. O progresso de desafios e a correção automática ainda precisam de armazenamento e executor seguro.
